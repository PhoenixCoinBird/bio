<div class="footer">
            <h2>I'm not sure I've learned anything..</h2>
        </div>