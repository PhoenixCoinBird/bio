            <nav>
                <ul>
                    <li><a href="#"> Button1 </a></li>
                    <li><a href="#"> Button2 </a></li>
                    <li><a href="#"> Button3 </a></li>
                    <li><a href="#"> Button4 </a></li>
                    <li><a href="#"> Button5 </a></li>
                </ul>    
            </nav>