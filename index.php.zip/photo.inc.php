    
                <div class="img"> 
                <img src="img/1.png" alt="php">
                </div>                                                 
        