

<?php 
 $p = 'Hey, this is my Bio looks like';
?>

<?php 
 $name = 'Pavel';
 $surname = '';
 $city = 'NY';
 $age = 34;
?>


<?php
include 'main.php';
?>

