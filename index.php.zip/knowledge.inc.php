
<?php
$a = 'My knowledge around';
$b = 100;
$c = '%'; 
?>

<?php
  $price = 88;

  if($price >= 75 && $price <= 100)
      $d = 'This number between 75 и 100';
?>
